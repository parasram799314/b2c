// ============================================================
//  ManagerPage.jsx
//  Manager yahan sirf approve/reject kar sakta hai.
//  Trips tab aati hain jab user SendToManagerButton click kare.
// ============================================================
import { useAuth }        from '../context/AuthContext';
import { useTripReview }  from '../context/TripReviewContext';

const STATUS = {
  pending:  { bg: '#fef3c7', color: '#92400e', label: '⏳ Pending'  },
  approved: { bg: '#d1fae5', color: '#065f46', label: '✅ Approved' },
  rejected: { bg: '#fee2e2', color: '#991b1b', label: '❌ Rejected' },
};

function Badge({ status }) {
  const s = STATUS[status] || STATUS.pending;
  return (
    <span style={{
      background: s.bg, color: s.color,
      padding: '2px 10px', borderRadius: 20,
      fontSize: 11, fontWeight: 700,
    }}>{s.label}</span>
  );
}

export default function ManagerPage() {
  const { user, logout }                    = useAuth();
  const { trips, approveTrip, rejectTrip }  = useTripReview();

  const counts = {
    total:    trips.length,
    pending:  trips.filter(t => t.status === 'pending').length,
    approved: trips.filter(t => t.status === 'approved').length,
    rejected: trips.filter(t => t.status === 'rejected').length,
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f1f5f9', fontFamily: "'Segoe UI',sans-serif" }}>

      {/* ── Topbar ── */}
      <div style={{
        background: '#1e293b', height: 56,
        display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', padding: '0 24px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 18 }}>✈️</span>
          <span style={{ color: '#fff', fontWeight: 800, fontSize: 15 }}>Travel Portal</span>
          <span style={{
            background: 'rgb(247,190,57)', color: '#1a1a1a',
            padding: '1px 9px', borderRadius: 20, fontSize: 10, fontWeight: 800,
          }}>MANAGER</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span style={{ color: '#94a3b8', fontSize: 13 }}>👋 {user.name}</span>
          <button onClick={logout} style={{
            background: 'transparent', border: '1px solid #475569',
            color: '#94a3b8', padding: '5px 13px', borderRadius: 8,
            cursor: 'pointer', fontSize: 12, fontWeight: 600,
          }}>Logout</button>
        </div>
      </div>

      {/* ── Content ── */}
      <div style={{ padding: '28px 24px', maxWidth: 860, margin: '0 auto' }}>

        <h1 style={{ margin: '0 0 4px', fontSize: 20, fontWeight: 800, color: '#1e293b' }}>
          Trip Approvals
        </h1>
        <p style={{ margin: '0 0 22px', fontSize: 13, color: '#64748b' }}>
          Jab bhi user "Send to Manager" click karega, trip yahan aayegi.
        </p>

        {/* ── Stat cards ── */}
        <div style={{ display: 'flex', gap: 14, marginBottom: 26 }}>
          {[
            ['Total',    counts.total,    '#e0e7ff','#3730a3'],
            ['Pending',  counts.pending,  '#fef3c7','#92400e'],
            ['Approved', counts.approved, '#d1fae5','#065f46'],
            ['Rejected', counts.rejected, '#fee2e2','#991b1b'],
          ].map(([label, val, bg, col]) => (
            <div key={label} style={{
              flex: 1, background: '#fff', borderRadius: 14,
              padding: '14px 10px', textAlign: 'center',
              border: `2px solid ${bg}`,
            }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: col }}>{val}</div>
              <div style={{ fontSize: 10, color: '#64748b', fontWeight: 700,
                textTransform: 'uppercase', letterSpacing: '.05em', marginTop: 2 }}>
                {label}
              </div>
            </div>
          ))}
        </div>

        {/* ── Trip list ── */}
        {trips.length === 0 ? (
          <div style={{
            background: '#fff', borderRadius: 16,
            padding: '52px 20px', textAlign: 'center',
            border: '2px dashed #e2e8f0',
          }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>📭</div>
            <div style={{ fontWeight: 700, color: '#475569' }}>Abhi koi trip nahi</div>
            <div style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>
              User "Send to Manager" click karega toh yahan dikhega
            </div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {trips.map(trip => (
              <div key={trip.id} style={{
                background: '#fff', borderRadius: 16,
                padding: '18px 22px', border: '1px solid #e2e8f0',
                boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    {/* Route + badge */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                      <span style={{ fontSize: 15, fontWeight: 800, color: '#1e293b' }}>
                        ✈️ {trip.from} → {trip.to}
                      </span>
                      <Badge status={trip.status} />
                    </div>
                    {/* Meta */}
                    <div style={{ display: 'flex', gap: 18, fontSize: 12, color: '#64748b', marginBottom: 6 }}>
                      <span>👤 {trip.submittedBy}</span>
                      <span>📅 {trip.travelDate}</span>
                      <span>👥 {trip.passengers} pax</span>
                      {trip.budget && <span>💰 ₹{Number(trip.budget).toLocaleString('en-IN')}</span>}
                    </div>
                    {/* Notes */}
                    {trip.notes && (
                      <div style={{
                        background: '#f8fafc', borderRadius: 8,
                        padding: '7px 11px', fontSize: 12, color: '#475569',
                        borderLeft: '3px solid rgb(247,190,57)', marginTop: 6,
                      }}>
                        📝 {trip.notes}
                      </div>
                    )}
                    <div style={{ fontSize: 10, color: '#94a3b8', marginTop: 8 }}>
                      Submitted: {new Date(trip.submittedAt).toLocaleString('en-IN')}
                    </div>
                  </div>

                  {/* Action buttons — only for pending */}
                  {trip.status === 'pending' && (
                    <div style={{ display: 'flex', gap: 8, marginLeft: 18, flexShrink: 0 }}>
                      <button onClick={() => approveTrip(trip.id)} style={{
                        padding: '7px 16px', background: '#10b981', color: '#fff',
                        border: 'none', borderRadius: 9,
                        fontSize: 12, fontWeight: 700, cursor: 'pointer',
                      }}
                        onMouseEnter={e => e.target.style.background = '#059669'}
                        onMouseLeave={e => e.target.style.background = '#10b981'}
                      >✅ Approve</button>
                      <button onClick={() => rejectTrip(trip.id)} style={{
                        padding: '7px 16px', background: '#ef4444', color: '#fff',
                        border: 'none', borderRadius: 9,
                        fontSize: 12, fontWeight: 700, cursor: 'pointer',
                      }}
                        onMouseEnter={e => e.target.style.background = '#dc2626'}
                        onMouseLeave={e => e.target.style.background = '#ef4444'}
                      >❌ Reject</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
